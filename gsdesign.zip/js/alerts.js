let alertnofunction = document.querySelector('.nofunction');

alertnofunction.addEventListener('click', () => {
    alert ("Lo lamentamos, pronto tendremos esta  opción.");
});

let alertnofunction1 = document.querySelector('.nofunction1');

alertnofunction1.addEventListener('click', () => {
    alert ("Lo lamentamos, pronto tendremos esta  opción.");
});

let alertnofunction2 = document.querySelector('.nofunction2');

alertnofunction2.addEventListener('click', () => {
    alert ("Lo lamentamos, pronto tendremos esta  opción.");
});

let alertnofunction3 = document.querySelector('.nofunction3');

alertnofunction3.addEventListener('click', () => {
    alert ("Lo lamentamos, pronto tendremos esta  opción.");
});